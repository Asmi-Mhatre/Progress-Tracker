export type Category = "Academics" | "Career" | "Startup" | "Personal" | "Financial";
export type GoalStatus = "active" | "paused" | "done";
export interface Goal { id: string; name: string; category: Category; weight: number; status: GoalStatus; targetDate?: string; notes: string; parentId?: string }
export interface Task { id: string; title: string; goalId?: string; priority: 1 | 2 | 3; due?: string; estMin: number; done: boolean; createdAt: string }
export interface Block { id: string; title: string; goalId?: string; start: string; durMin: number; kind: "once" | "weekly" | "monthly"; date?: string; days: number[]; monthDay?: number; fixed: boolean; productive: boolean }
export interface Log { id: string; blockId: string; date: string; status: "done" | "partial" | "skipped" | "rescheduled"; actualMin: number; notes: string }
export interface Session { id: string; goalId?: string; taskId?: string; date: string; plannedMin: number; actualMin: number; distractions: number; completed: boolean; notes: string }
export interface Settings { sleepStart: string; sleepEnd: string }
export interface DB { goals: Goal[]; tasks: Task[]; blocks: Block[]; logs: Log[]; sessions: Session[]; settings: Settings }
export const CATEGORIES: Category[] = ["Academics", "Career", "Startup", "Personal", "Financial"];
