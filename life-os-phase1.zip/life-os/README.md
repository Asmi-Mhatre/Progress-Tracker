# Life OS (Phase 1)

Next.js 14 + TypeScript + Tailwind. Data lives in browser localStorage with JSON export/import (Settings).

## Run
    npm install
    npm run dev        # http://localhost:3000
    npm run build

## Deploy
1. `git init && git add . && git commit -m "Life OS phase 1"`
2. Create an empty GitHub repo, then `git remote add origin <url> && git push -u origin main`
3. On vercel.com: Add New > Project > import the repo > Deploy (no env vars needed yet).
4. To update: commit and push to `main`; Vercel redeploys automatically.

Note: localStorage is per browser and per device. Supabase sync arrives in a later phase.
