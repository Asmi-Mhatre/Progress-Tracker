export type Category = "Academics" | "Career" | "Startup" | "Personal" | "Financial";
export type GoalStatus = "active" | "paused" | "done";
export interface Goal { id: string; name: string; category: Category; weight: number; status: GoalStatus; targetDate?: string; notes: string; parentId?: string }
export interface Task { id: string; title: string; goalId?: string; priority: 1 | 2 | 3; due?: string; estMin: number; done: boolean; createdAt: string }
export interface DB { goals: Goal[]; tasks: Task[] }
export const CATEGORIES: Category[] = ["Academics", "Career", "Startup", "Personal", "Financial"];
